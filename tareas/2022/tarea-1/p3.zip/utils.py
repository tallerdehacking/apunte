from ecdsa.ecdsa import Signature, generator_256
import hashlib

BUF_SIZE = 65535

# This function opens a file and hashes it.
def hash(filename):
    sha256 = hashlib.sha256()
    with open(filename, 'rb') as f:
        while True:
            data = f.read(BUF_SIZE)
            if not data:
                break
            sha256.update(data)
    return sha256.hexdigest()

# An hexstring can be interpreted as a number if it is
# represented as an hexstring.
def hexstring2dec(hash):
    return int(hash, 16)

# This was written by GitHub Copilot.
# I do not know why (and if) it works!
def dec2hexstring(num):
    return hex(num)[2:]

# Saves a signature into a file
# First line is R
# Second line is S
def save_signature(signature, file):
    with open(f"{file}.sig", 'w') as f:
        f.write(f"{signature.r}\n{signature.s}\n")

# Loads a signature from a file
# First line must be R
# Second line must be S
def load_signature(sigfile):
    with open(sigfile, 'r') as f:
        r = int(f.readline().strip())
        s = int(f.readline().strip())
    return Signature(r, s)

# I don't know why this is here.
# Ignore it and move on with your life.
def modinv(a, m):
    def egcd(a, b):
        if a == 0:
            return (b, 0, 1)
        else:
            g, y, x = egcd(b % a, a)
            return (g, x - (b // a) * y, y)
    g, x, y = egcd(a, m)
    if g != 1:
        raise Exception('modular inverse does not exist')
    else:
        return x % m

# Checks if a signed file is well signed
def verify(file):
    e = hexstring2dec(hash(file))
    signature = load_signature(file + ".sig")

    r = signature.r
    s = signature.s

    pubkeys = signature.recover_public_keys(e, generator_256)
    verified = False

    for pubkey in pubkeys:
        if pubkey.verifies(e, signature):
            verified = True
            break
    return verified
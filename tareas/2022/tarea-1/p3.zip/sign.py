from ecdsa.ecdsa import generator_256, Public_key, Private_key
import sys
import os
from verify import *
from utils import *

if __name__ == "__main__":
    from random import SystemRandom
    randrange = SystemRandom().randrange

    G = generator_256
    n = G.order()


    k = randrange(1, n)
    m = randrange(1, n)

    print(f"k = {dec2hexstring(k)}")
    print(f"m = {dec2hexstring(m)}")

    pubkey = Public_key( G, G * k )
    privkey = Private_key( pubkey, k )

    if len(sys.argv) < 3:
        print("Usage: sign.py <filename1> <filename2> ...")
        os.exit(1)

    for file in sys.argv[1:]:
        e = hexstring2dec(hash(file))
        signature = privkey.sign(e, m)
        save_signature(signature, file)
        if verify(file):
            print(f"Signature of {file} is valid")
        else:
            print(f"Signature of {file} is invalid")
    
    print(f"Recovered key: {dec2hexstring(recover_key(sys.argv[1:]))}")
import rsa
import random 

from constants import FLAG

MODULUS_SIZE=2048
PUBLIC_EXPONENT=3 # It is faster!


def gen_key():
    '''
    returns a public key, composed by the modulus (n)
    and the public exponent (e)
    '''
    # Secret key is lost forever!
    pk, _ = rsa.newkeys(MODULUS_SIZE, exponent=PUBLIC_EXPONENT)
    return pk['n'], pk['e']


def encode_to_int(message):
    '''
    transforms a message into an integer.
    '''
    msg_int = 0
    for char in message:
        msg_int = msg_int + ord(char)
        msg_int <<= 8
    msg_int >>= 8
    return msg_int


def decode_from_int(msg_int):
    '''
    transforms an integer into a message.
    '''
    msg_chr = ""
    while msg_int != 0:
        c = chr(int(msg_int % 256))
        msg_chr = c + msg_chr
        msg_int >>= 8
    return msg_chr


def encrypt(message, modulus, exponent):
    '''
    Encrypts a text message using a given public modulus.
    '''
    msg_int = encode_to_int(message)
    exp = pow(msg_int, exponent, modulus)
    return exp


if __name__ == "__main__":
    encrypted = []

    n, e = gen_key()
    encrypted.append(hex(encrypt(FLAG, n, e)))

    with open("plaintext.txt") as in_file:
        for i, line in enumerate(in_file):
            enc = encrypt(line, n, e)
            encrypted.append(hex(enc)+'\n')
    random.shuffle(encrypted)

    with open("encrypted.txt", "w") as out_file:
        out_file.writelines(encrypted)
